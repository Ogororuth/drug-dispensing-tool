<?php
$host = "localhost";
$username = "root";
$databasePassword = "MySQLXXX-123a8910";
$databaseName = "ruth_nyakio";
?>
