<?php
header("Location: basic/home.php");
exit;
?>
