CREATE TABLE IF NOT EXISTS administrator (
    administratorId INT AUTO_INCREMENT PRIMARY KEY,
    emailAddress VARCHAR(100) NOT NULL,
    phoneNumber VARCHAR(20),
    gender ENUM('Male', 'Female', 'Other'),
    passwordHash VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS patient (
    patientId INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    gender ENUM('Male', 'Female', 'Other'),
    emailAddress VARCHAR(100) NOT NULL,
    phoneNumber VARCHAR(20),
    SSN VARCHAR(15) UNIQUE,
    dateOfBirth DATE,
    passwordHash VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS doctor (
    doctorId INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    gender ENUM('Male', 'Female', 'Other'),
    emailAddress VARCHAR(100) NOT NULL,
    phoneNumber VARCHAR(20),
    SSN VARCHAR(15) UNIQUE,
    passwordHash VARCHAR(100) NOT NULL
);

CREATE TABLE IF NOT EXISTS patient_doctor (
    patientDoctorId INT AUTO_INCREMENT PRIMARY KEY,
    patientId INT,
    doctorId INT,
    isPrimary BOOLEAN,
    FOREIGN KEY (patientId) REFERENCES patient(patientId),
    FOREIGN KEY (doctorId) REFERENCES doctor(doctorId)
);

CREATE TABLE IF NOT EXISTS pharmacy (
    pharmacyId INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    emailAddress VARCHAR(100) NOT NULL,
    phoneNumber VARCHAR(20)
);

CREATE TABLE IF NOT EXISTS pharmaceutical (
    pharmaceuticalId INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    emailAddress VARCHAR(100) NOT NULL,
    phoneNumber VARCHAR(20)
);

CREATE TABLE IF NOT EXISTS supervisor (
    supervisorId INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    pharmaceuticalId INT,
    emailAddress VARCHAR(100) NOT NULL,
    SSN VARCHAR(15) UNIQUE,
    passwordHash VARCHAR(100) NOT NULL,
    FOREIGN KEY (pharmaceuticalId) REFERENCES pharmaceutical(pharmaceuticalId)
);

CREATE TABLE IF NOT EXISTS pharmacist (
    pharmacistId INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    emailAddress VARCHAR(100) NOT NULL,
    phoneNumber VARCHAR(20),
    SSN VARCHAR(15) UNIQUE,
    pharmacyId INT,
    passwordHash VARCHAR(100) NOT NULL,
    FOREIGN KEY (pharmacyId) REFERENCES pharmacy(pharmacyId)
);

CREATE TABLE IF NOT EXISTS contract (
    contractId INT AUTO_INCREMENT PRIMARY KEY,
    dateCreated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    startDate DATE,
    endDate DATE,
    pharmacyId INT,
    pharmaceuticalId INT,
    FOREIGN KEY (pharmacyId) REFERENCES pharmacy(pharmacyId),
    FOREIGN KEY (pharmaceuticalId) REFERENCES pharmaceutical(pharmaceuticalId)
);

CREATE TABLE IF NOT EXISTS drug (
    drugId INT AUTO_INCREMENT PRIMARY KEY,
    scientificName VARCHAR(100),
    tradeName VARCHAR(100),
    contractId INT,
    form VARCHAR(50),
    FOREIGN KEY (contractId) REFERENCES contract(contractId)
);

CREATE TABLE IF NOT EXISTS prescription (
    prescriptionId INT AUTO_INCREMENT PRIMARY KEY,
    drugId INT,
    dosage VARCHAR(50),
    patientDoctorId INT,
    price DECIMAL(10, 2),
    frequency VARCHAR(50),
    isDispensed BOOLEAN,
    FOREIGN KEY (drugId) REFERENCES drug(drugId),
    FOREIGN KEY (patientDoctorId) REFERENCES patient_doctor(patientDoctorId)
);
